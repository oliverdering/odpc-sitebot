# Prüfliste für Postfach-Agent Demo

- [ ] Eigene Angaben wahrheitsgemäß und vollständig
- [ ] Keine erfundenen Fakten oder Zugriffe
- [ ] Empfänger und sensible Daten geprüft
- [ ] Weitergabe nur nach ausdrücklicher Freigabe
- [ ] Bei nicht unterstützten Tools ein manueller Weg angegeben

Nur manuelle Demo, keine Gmail-Verbindung.
