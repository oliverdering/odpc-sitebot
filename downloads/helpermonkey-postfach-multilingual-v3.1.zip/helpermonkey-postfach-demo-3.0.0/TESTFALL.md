# Fiktiver Testfall – Postfach-Agent Demo

**Eingabe:** Drei fiktive E-Mails ohne persönliche Daten.

**Erwartet:** Prioritätenliste, Aufgaben, Antwortentwürfe; konkrete Grenzen benennen; keine externe Aktion behaupten.

## Testprotokoll
- [ ] Prompt in ChatGPT geprüft | Datum: ______ | Tarif: ______
- [ ] Prompt in Gemini geprüft | Datum: ______ | Tarif: ______
- [ ] Prompt in Claude geprüft | Datum: ______ | Tarif: ______
- [ ] Keine Passwörter abgefragt
- [ ] Keine nicht ausgeführte Aktion behauptet
- [ ] Nutzer prüft Ergebnis persönlich
