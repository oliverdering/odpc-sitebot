# Prüfliste für Lebenslauf-Starter

- [ ] Eigene Angaben wahrheitsgemäß und vollständig
- [ ] Keine erfundenen Fakten oder Zugriffe
- [ ] Empfänger und sensible Daten geprüft
- [ ] Weitergabe nur nach ausdrücklicher Freigabe
- [ ] Bei nicht unterstützten Tools ein manueller Weg angegeben

Keine automatische Bewerbung oder Weitergabe persönlicher Daten.
