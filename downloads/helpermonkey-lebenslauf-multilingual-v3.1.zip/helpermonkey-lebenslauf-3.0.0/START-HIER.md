# helper · monkey © | Lebenslauf-Starter

**Paket-Version:** 3.0.0 | **Stand:** 13.10.2026 | **Status:** kostenlose Testversion
**Anbieter:** odpc.de | **Produktplattform:** ai.odpc.de

## Was erhältst du?
Beruflichen Werdegang professionell und wahrheitsgemäß formulieren. Ergebnis: Lebenslaufentwurf, Verbesserungen, Prüfliste.

## Schnellstart
1. Öffne einen unterstützten KI-Chat (ChatGPT, Gemini oder Claude), soweit verfügbar.
2. Kopiere den gesamten Text aus MASTERPROMPT.txt in einen neuen Chat.
3. Folge den Fragen des Assistenten. Benutze zum Test zuerst fiktive oder anonymisierte Daten.
4. Prüfe das Ergebnis und exportiere es selbst.

**Wichtig:** Dieser Download installiert keine App, erzeugt keine Kontoverbindung und startet keinen Hintergrunddienst. Ob ein Tool verfügbar ist, hängt vom genutzten Anbieter, Tarif und deinen erteilten Berechtigungen ab.

## Grenzen
Keine automatische Bewerbung oder Weitergabe persönlicher Daten.

## Schutz persönlicher Daten
Keine Passwörter, Einmalcodes, Tokens oder fremde vertrauliche Inhalte im Chat eingeben. Versand, Löschung, Veröffentlichung und Käufe nur nach gesonderter bestätigter Freigabe.

## Hilfe
https://ai.odpc.de · https://odpc.de · Support: oliver.dering@odpc.de
