# Prüfliste für Connector 3.0

- [ ] Eigene Angaben wahrheitsgemäß und vollständig
- [ ] Keine erfundenen Fakten oder Zugriffe
- [ ] Empfänger und sensible Daten geprüft
- [ ] Weitergabe nur nach ausdrücklicher Freigabe
- [ ] Bei nicht unterstützten Tools ein manueller Weg angegeben

Verbindungen sind nicht durch einen Prompt allein hergestellt.
