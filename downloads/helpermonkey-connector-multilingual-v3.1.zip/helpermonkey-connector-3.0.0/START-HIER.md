# helper · monkey © | Connector 3.0

**Paket-Version:** 3.0.0 | **Stand:** 13.10.2026 | **Status:** kostenlose Testversion
**Anbieter:** odpc.de | **Produktplattform:** ai.odpc.de

## Was erhältst du?
Konten, Apps und verfügbare Verbindungen realistisch prüfen. Ergebnis: Verbindungscheck, Ampelstatus, sichere Freigaben.

## Schnellstart
1. Öffne einen unterstützten KI-Chat (ChatGPT, Gemini oder Claude), soweit verfügbar.
2. Kopiere den gesamten Text aus MASTERPROMPT.txt in einen neuen Chat.
3. Folge den Fragen des Assistenten. Benutze zum Test zuerst fiktive oder anonymisierte Daten.
4. Prüfe das Ergebnis und exportiere es selbst.

**Wichtig:** Dieser Download installiert keine App, erzeugt keine Kontoverbindung und startet keinen Hintergrunddienst. Ob ein Tool verfügbar ist, hängt vom genutzten Anbieter, Tarif und deinen erteilten Berechtigungen ab.

## Grenzen
Verbindungen sind nicht durch einen Prompt allein hergestellt.

## Schutz persönlicher Daten
Keine Passwörter, Einmalcodes, Tokens oder fremde vertrauliche Inhalte im Chat eingeben. Versand, Löschung, Veröffentlichung und Käufe nur nach gesonderter bestätigter Freigabe.

## Hilfe
https://ai.odpc.de · https://odpc.de · Support: oliver.dering@odpc.de
