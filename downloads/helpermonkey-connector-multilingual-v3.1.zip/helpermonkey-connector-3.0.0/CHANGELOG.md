# Änderungen

3.0.0 (13.10.2026) – kostenloses Testpaket; standardisierte Prompt- und Sicherheitsregeln.
